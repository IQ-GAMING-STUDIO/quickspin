apple = '/Apple.png'
banana = '/Banana.png'
pear = '/Pear.png'

question_mark = "/Question.png"