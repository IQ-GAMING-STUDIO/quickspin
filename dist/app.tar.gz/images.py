apple = 'https://drive.google.com/uc?export=view&id=1FHbhHtDegECxBStYCCYXv1Mv1KShSFhv'
banana = 'https://drive.google.com/uc?export=view&id=1khKr49vOf9vLvPOh7XhoZBzCOhvg_7B1'
pear = 'https://drive.google.com/uc?export=view&id=1ZGk-O4H90p38mQ-YJFEpL8vv5npPNjhw'

question_mark = "https://drive.google.com/uc?export=view&id=1gnVL3_f2UggUJC7R085Bak5J2Jb-TDq9"